﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Private_School_Managment
{
    public class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public double TuititionFees { get; set; }
        //One Student Can Be only, in one Course//
        public Course Course { get; set; } = new Course();
        //One student is Related to Many assigments//
        public List<Assignment> Assignments { get; set; } = new List<Assignment>();
        //One student is Related to many trainers, because one Cource can
        //obtain many trainers.
        public List<Trainer> Trainers { get; set; } = new List<Trainer>();
    }
}
