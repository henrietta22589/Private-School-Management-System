﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Private_School_Managment
{
    public class Trainer
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        // One Trainer can be Related to many Courses//
        public List<Course> Courses { get; set; } = new List<Course>();
        //One Trainer is obligated to examine multiple Assigments//
        public List<Assignment>Assignments { get; set; }
    }
}
